import requests

# ✅ Replace with your actual Cloud Run service URL
BASE_URL = "https://june-tts-359243954.us-central1.run.app"

def test_tts():
    url = f"{BASE_URL}/v1/tts"
    params = {
        "text": "Hello, this is a Cloud Run TTS test!",
        "language_code": "en-US",
        "voice_name": "en-US-Wavenet-D",
        "audio_encoding": "MP3"
    }
    print(f"➡️ POST {url} with params={params}")
    resp = requests.post(url, params=params, timeout=60)
    print("Status code:", resp.status_code)

    if resp.status_code == 200:
        with open("test.mp3", "wb") as f:
            f.write(resp.content)
        print("✅ TTS request succeeded, saved test.mp3")
    else:
        print("❌ TTS request failed")
        print("Response text:", resp.text)

if __name__ == "__main__":
    test_tts()
