from fastapi import FastAPI, Query
from fastapi.responses import StreamingResponse, JSONResponse
from google.cloud import texttospeech
from google.oauth2 import service_account
import io, os, json

APP_TITLE = "june-tts"
app = FastAPI(title=APP_TITLE)

_tts_client = None

def build_tts_client():
    if os.getenv("GOOGLE_APPLICATION_CREDENTIALS"):
        return texttospeech.TextToSpeechClient()

    sa_path = os.getenv("GCP_SA_PATH")
    if sa_path and os.path.exists(sa_path):
        creds = service_account.Credentials.from_service_account_file(sa_path)
        return texttospeech.TextToSpeechClient(credentials=creds)

    sa_json = os.getenv("GCP_SA_JSON")
    if sa_json:
        info = json.loads(sa_json)
        creds = service_account.Credentials.from_service_account_info(info)
        return texttospeech.TextToSpeechClient(credentials=creds)

    return texttospeech.TextToSpeechClient()

def get_client():
    global _tts_client
    if _tts_client is None:
        _tts_client = build_tts_client()
    return _tts_client


@app.get("/healthz")
async def healthz():
    try:
        _ = get_client()
        return {"ok": True, "service": APP_TITLE}
    except Exception as e:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})


@app.post("/v1/tts")
async def synthesize_speech(
    text: str = Query(..., description="Text to synthesize"),
    language_code: str = Query("en-US"),
    voice_name: str = Query("en-US-Wavenet-D"),
    audio_encoding: str = Query("MP3"),  # or LINEAR16 / OGG_OPUS
):
    client = get_client()
    synthesis_input = texttospeech.SynthesisInput(text=text)

    voice = texttospeech.VoiceSelectionParams(
        language_code=language_code,
        name=voice_name,
    )

    audio_config = texttospeech.AudioConfig(
        audio_encoding=getattr(texttospeech.AudioEncoding, audio_encoding)
    )

    response = client.synthesize_speech(
        input=synthesis_input,
        voice=voice,
        audio_config=audio_config,
    )

    audio_bytes = response.audio_content
    filename = f"speech.{audio_encoding.lower()}"
    return StreamingResponse(io.BytesIO(audio_bytes),
                             media_type="audio/mpeg" if audio_encoding=="MP3" else "audio/wav",
                             headers={"Content-Disposition": f"attachment; filename={filename}"})


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8080)
