import asyncio
import websockets
import json
import sounddevice as sd
import numpy as np

BASE_URL = "wss://june-stt-359243954.us-central1.run.app/v1/stream"


async def stream_mic():
    async with websockets.connect(BASE_URL, ping_interval=None) as ws:
        # send start signal
        await ws.send(json.dumps({"type": "start", "language_code": "en-US"}))
        print("✅ Connected, start speaking... (Ctrl+C to stop)")

        sample_rate = 16000
        chunk_ms = 100
        chunk_size = int(sample_rate * chunk_ms / 1000)

        async def sender():
            with sd.InputStream(samplerate=sample_rate, channels=1, dtype="int16") as stream:
                while True:
                    data, _ = stream.read(chunk_size)
                    await ws.send(data.tobytes())

        async def receiver():
            async for msg in ws:
                print("STT:", msg)

        await asyncio.gather(sender(), receiver())

if __name__ == "__main__":
    asyncio.run(stream_mic())
