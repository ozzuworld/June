from __future__ import annotations

import io, json, os, subprocess, wave, threading
from typing import Optional
import asyncio
import queue as thread_queue

from fastapi import FastAPI, File, UploadFile, WebSocket, WebSocketDisconnect, HTTPException, Query
from fastapi.responses import JSONResponse
from google.cloud import speech
from google.oauth2 import service_account

APP_TITLE = "june-stt"
DEFAULT_SAMPLE_RATE = 16000

_speech_client: Optional[speech.SpeechClient] = None


def build_speech_client() -> speech.SpeechClient:
    # Prefer ADC (GOOGLE_APPLICATION_CREDENTIALS). Fallback to explicit env vars.
    if os.getenv("GOOGLE_APPLICATION_CREDENTIALS"):
        return speech.SpeechClient()
    sa_path = os.getenv("GCP_SA_PATH")
    if sa_path and os.path.exists(sa_path):
        creds = service_account.Credentials.from_service_account_file(sa_path)
        return speech.SpeechClient(credentials=creds)
    sa_json = os.getenv("GCP_SA_JSON")
    if sa_json:
        info = json.loads(sa_json)
        creds = service_account.Credentials.from_service_account_info(info)
        return speech.SpeechClient(credentials=creds)
    # Last resort: default client
    return speech.SpeechClient()


def get_cached_speech_client() -> speech.SpeechClient:
    global _speech_client
    if _speech_client is None:
        _speech_client = build_speech_client()
    return _speech_client


app = FastAPI(title=APP_TITLE)


def _has_ffmpeg() -> bool:
    try:
        subprocess.run(["ffmpeg", "-version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
        return True
    except FileNotFoundError:
        return False


def ensure_linear16_16k_mono(data: bytes) -> bytes:
    # If it's already WAV PCM 16-bit mono @ 16kHz, strip header and return frames
    try:
        with wave.open(io.BytesIO(data), "rb") as wf:
            if (
                wf.getnchannels() == 1
                and wf.getsampwidth() == 2
                and wf.getframerate() == DEFAULT_SAMPLE_RATE
                and wf.getcomptype() == "NONE"
            ):
                return wf.readframes(wf.getnframes())
    except wave.Error:
        pass

    # Otherwise, use ffmpeg to convert (if available)
    if not _has_ffmpeg():
        raise HTTPException(
            status_code=400,
            detail="Audio must be PCM WAV 16-bit mono @16kHz when ffmpeg is not installed.",
        )

    p = subprocess.run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            "-",
            "-ac",
            "1",
            "-ar",
            str(DEFAULT_SAMPLE_RATE),
            "-f",
            "s16le",
            "-",
        ],
        input=data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=True,
    )
    return p.stdout


@app.post("/v1/stt")
async def stt_file(
    file: UploadFile = File(...),
    language_code: str = Query("en-US"),
    enable_punctuation: bool = Query(True),
    enable_word_time_offsets: bool = Query(False),
):
    # Batch file transcription endpoint
    raw = await file.read()
    await file.close()
    pcm = ensure_linear16_16k_mono(raw)

    cfg = speech.RecognitionConfig(
        encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=DEFAULT_SAMPLE_RATE,
        language_code=language_code,
        max_alternatives=1,
        enable_automatic_punctuation=enable_punctuation,
        enable_word_time_offsets=enable_word_time_offsets,
        model="latest_long",
    )
    audio = speech.RecognitionAudio(content=pcm)
    resp = get_cached_speech_client().recognize(config=cfg, audio=audio)

    results = []
    for r in resp.results:
        alt = r.alternatives[0]
        item = {
            "text": alt.transcript,
            "confidence": getattr(alt, "confidence", 0.0),
            "is_final": True,
        }
        if enable_word_time_offsets:
            item["words"] = [
                {
                    "word": w.word,
                    "start_ms": int(w.start_time.seconds * 1000 + w.start_time.nanos / 1e6),
                    "end_ms": int(w.end_time.seconds * 1000 + w.end_time.nanos / 1e6),
                }
                for w in alt.words
            ]
        results.append(item)
    text = " ".join(x["text"].strip() for x in results).strip()
    return {"text": text, "segments": results}


def _gcp_streaming_worker(
    audio_q: thread_queue.Queue,
    language_code: str,
    loop: asyncio.AbstractEventLoop,
    ws: WebSocket,
):
    """
    Blocking worker thread:
      - Builds streaming requests from queue
      - Iterates Google responses
      - Sends JSON back to the WS via the main asyncio loop
    """
    client = get_cached_speech_client()

    base_cfg = speech.RecognitionConfig(
        encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=DEFAULT_SAMPLE_RATE,
        language_code=language_code,
        max_alternatives=1,
        enable_automatic_punctuation=True,
        model="latest_long",
    )
    streaming_cfg = speech.StreamingRecognitionConfig(
        config=base_cfg,
        interim_results=True,   # low-latency partials
        single_utterance=False, # keep stream open
    )

    def request_iter():
        # when passing config=streaming_cfg to streaming_recognize,
        # we only yield audio_content requests here
        while True:
            chunk = audio_q.get()
            if chunk is None:
                break
            yield speech.StreamingRecognizeRequest(audio_content=chunk)

    try:
        # IMPORTANT: pass config explicitly (fixes the earlier error)
        responses = client.streaming_recognize(config=streaming_cfg, requests=request_iter())

        for response in responses:
            for result in response.results:
                alt = result.alternatives[0]
                payload = {
                    "type": "transcript",
                    "text": alt.transcript,
                    "is_final": result.is_final,
                    "confidence": getattr(alt, "confidence", 0.0),
                }
                fut = asyncio.run_coroutine_threadsafe(ws.send_json(payload), loop)
                try:
                    fut.result()
                except Exception:
                    return
    except Exception as e:
        try:
            asyncio.run_coroutine_threadsafe(ws.send_json({"type": "error", "error": str(e)}), loop).result()
        except Exception:
            pass


@app.websocket("/v1/stream")
async def ws_stream(ws: WebSocket):
    # Proper WS route (was mis-declared before)
    await ws.accept()
    language_code = "en-US"
    audio_q: thread_queue.Queue[Optional[bytes]] = thread_queue.Queue(maxsize=200)
    loop = asyncio.get_running_loop()
    worker_thread: Optional[threading.Thread] = None

    # Start message back to client
    await ws.send_json({"type": "ready", "language_code": language_code})

    try:
        while True:
            msg = await ws.receive()

            # Control messages
            if "text" in msg and msg["text"] is not None:
                try:
                    data = json.loads(msg["text"])
                except Exception:
                    data = {}

                t = data.get("type")
                if t == "start":
                    language_code = data.get("language_code", language_code)
                    if worker_thread is None or not worker_thread.is_alive():
                        worker_thread = threading.Thread(
                            target=_gcp_streaming_worker,
                            args=(audio_q, language_code, loop, ws),
                            daemon=True,
                        )
                        worker_thread.start()
                    await ws.send_json({"type": "ready", "language_code": language_code})

                elif t == "stop":
                    audio_q.put(None)
                    if worker_thread and worker_thread.is_alive():
                        worker_thread.join(timeout=2.0)
                    await ws.send_json({"type": "stopped"})
                    await ws.close()
                    break

                elif t == "barge_in":
                    # If you synthesize TTS, cancel it here.
                    await ws.send_json({"type": "barge_in_ack"})

                else:
                    # ignore unknown controls
                    pass

            # Audio bytes
            elif "bytes" in msg and msg["bytes"] is not None:
                try:
                    audio_q.put_nowait(msg["bytes"])
                except thread_queue.Full:
                    try:
                        _ = audio_q.get_nowait()
                        audio_q.put_nowait(msg["bytes"])
                    except Exception:
                        pass

            else:
                # ignore other frames
                pass

    except WebSocketDisconnect:
        try:
            audio_q.put_nowait(None)
        except Exception:
            pass
        if worker_thread and worker_thread.is_alive():
            worker_thread.join(timeout=1.0)
    except Exception as e:
        try:
            await ws.send_json({"type": "error", "error": str(e)})
        except Exception:
            pass
        try:
            audio_q.put_nowait(None)
        except Exception:
            pass
        if worker_thread and worker_thread.is_alive():
            worker_thread.join(timeout=1.0)
        try:
            await ws.close()
        except Exception:
            pass


@app.get("/healthz")
async def healthz():
    try:
        client = get_cached_speech_client()
        _ = client.transport.grpc_channel  # touch channel
    except Exception as e:
        return JSONResponse(status_code=500, content={"ok": False, "error": str(e)})
    return {"ok": True, "service": APP_TITLE}
