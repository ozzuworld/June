import requests

BASE_URL = "https://june-orchestrator-359243954.us-central1.run.app"

def test_chat():
    url = f"{BASE_URL}/v1/chat"
    data = {"user_input": "Hello June, do you have multimodal capabilities like computer vision?"}
    resp = requests.post(url, json=data, timeout=60)

    print("Status:", resp.status_code)
    try:
        print("Response JSON:", resp.json())
    except Exception:
        print("Raw text:", resp.text)

if __name__ == "__main__":
    test_chat()
