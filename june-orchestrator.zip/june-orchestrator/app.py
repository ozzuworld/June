from fastapi import FastAPI, Body
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from langchain_google_vertexai import ChatVertexAI
from langchain.agents import initialize_agent, AgentType
from langchain.tools import Tool
from langchain.memory import ConversationBufferMemory

from typing import Any
import json, os, re, traceback, logging

from tools import get_weather, calculator

APP_TITLE = "june-orchestrator"
app = FastAPI(title=APP_TITLE)

# ---- CORS (relaxed for dev; tighten in prod) ----
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],           # ← keep simple while testing RN/emulator
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---- LLM ----
llm = ChatVertexAI(
    model="gemini-2.5-flash",       # change if your region requires
    temperature=0.7,
    project=os.getenv("GOOGLE_CLOUD_PROJECT"),
    location="us-central1",
)

# ---- Tools ----
tools = [
    Tool(name="Weather", func=get_weather,
         description="Get weather info for a city. Input = city name."),
    Tool(name="Calculator", func=calculator,
         description="Do basic math. Input = '2+2'."),
]

# ---- Memory ----
memory = ConversationBufferMemory(
    memory_key="chat_history",
    return_messages=True,
)

# ---- Agent ----
agent = initialize_agent(
    tools=tools,
    llm=llm,
    agent=AgentType.CONVERSATIONAL_REACT_DESCRIPTION,
    verbose=False,
    handle_parsing_errors=(
        "Parsing error; respond to the user directly in natural language."
    ),
    max_iterations=3,
    early_stopping_method="generate",
    memory=memory,
)

logger = logging.getLogger("uvicorn.error")


# ---------- helpers ----------
_POSSIBLE_KEYS = ("reply", "text", "message", "content", "assistant", "output")

def _strip_fences(s: str) -> str:
    s = s.strip()
    if s.startswith("```"):
        s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.DOTALL).strip()
    return s

def coerce_text(raw: Any) -> str:
    """Turn whatever the LLM/agent returns into a plain string."""
    if isinstance(raw, dict):
        for k in _POSSIBLE_KEYS:
            v = raw.get(k)
            if isinstance(v, str) and v.strip():
                return v.strip()
    if isinstance(raw, str):
        s = _strip_fences(raw)
        # If it's JSON-in-a-string, try to read it
        try:
            j = json.loads(s)
            return coerce_text(j) or s
        except Exception:
            return s
    # LangChain message objects (AIMessage) have .content
    if hasattr(raw, "content"):
        return coerce_text(getattr(raw, "content"))
    return str(raw or "").strip()


async def safe_direct_answer(user_text: str) -> str:
    """Ask the base model to answer directly; never JSON, never tool calls."""
    try:
        msg = llm.invoke(
            f"Reply directly and helpfully to the user. No JSON, no code fences.\n\nUser: {user_text}\nAssistant:"
        )
        return coerce_text(msg) or "I'm here."
    except Exception:
        logger.exception("Direct LLM fallback failed")
        return "I'm having some trouble answering right now, but I'm here to help."


# ---------- routes ----------
@app.get("/healthz")
async def healthz():
    return {"ok": True, "service": APP_TITLE}

@app.post("/v1/chat")
async def chat(user_input: str = Body(..., embed=True)):
    """
    Body: { "user_input": "Hello June" }
    Resp: { "reply": "..." }
    """
    try:
        # 1) Try the agent first
        result = agent.invoke({"input": user_input})
        # result is often a dict with "output", but be robust:
        reply = ""
        if isinstance(result, dict):
            reply = coerce_text(result.get("output")) or coerce_text(result)
        else:
            reply = coerce_text(result)

        # 2) If agent produced the classic parse string or empty → direct fallback
        bad = not reply or "could not parse llm output" in reply.lower()
        if bad:
            reply = await safe_direct_answer(user_input)

        # 3) Always return 200 so the app will TTS the reply
        return {"reply": reply}

    except Exception:
        logger.error("Error in /v1/chat", exc_info=True)
        # Still return 200 with a friendly reply (keeps the STT→ORC→TTS loop flowing)
        friendly = await safe_direct_answer(user_input)
        return {"reply": friendly}
